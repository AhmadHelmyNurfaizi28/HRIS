<?php

class RecruitmentExeption extends ServiceException {

}

