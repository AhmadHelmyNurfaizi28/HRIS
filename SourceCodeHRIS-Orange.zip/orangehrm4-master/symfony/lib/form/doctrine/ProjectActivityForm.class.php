<?php

/**
 * ProjectActivity form.
 *
 * @package    form
 * @subpackage ProjectActivity
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class ProjectActivityForm extends BaseProjectActivityForm
{
  public function configure()
  {
  }
}