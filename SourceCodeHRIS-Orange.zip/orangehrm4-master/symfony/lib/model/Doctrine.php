<?php

/**
 * Kept for backwards compatibility.
 *
 * TODO: Change usages of Doctrine:: to Doctrine_Core::
 * and remove this file.
 */
class Doctrine extends Doctrine_Core {

}